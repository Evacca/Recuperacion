package com.example.recuperacionciclo4;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState, Object view) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText nombreR = (EditText) findViewById(R.id.EmailRegister);
        final EditText contraseñaR = (EditText) findViewById(R.id.PasswordRegister);
        final Button btnregistroR = (Button) findViewById(R.id.buttonRegister);

        TextView registro = (TextView)findViewById(R.id.buttonRegister);
        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registro = new Intent(MainActivity.this, Registro.class);
                MainActivity.this.startActivity(registro);
                finish();
            }
        });

        public void Registro (View view){
            SQLiteOpen admin = new SQLiteOpen(context:this, name:"usuarios", factory:null, version:1)
            ;
            SQLiteDatabase BaseDeDatos = admin.getWritableDatabase();

            String nombre = nombreL.getText().toString();
            String contraseña = contraseñaL.getText().toString();

            if (!nombre.isEmpty() && !contraseña.isEmpty()) {
                ContentValues registro = new ContentValues();
                registro.put("nombre", nombre);
                registro.put("contraseña", contraseña);

                BaseDeDatos.insert("usuarios", null, registro);

                BaseDeDatos.close();

                nombreR.setText();
                contraseñaR.setText();

                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Debes llenar todos los campos", Toast.LENGTH_SHORT).show();

            }
        }

        private void initUI() {
            tilNewTask = findViewById(R.id.til_new_task);
            tilNewTask.setEndIconOnClickListener(v -> {
                Toast.makeText(MainActivity.this, "Add new task to list", Toast.LENGTH_SHORT)
                        .show();
            });

            etNewTask = findViewById(R.id.et_new_task);

            taskAdapter = new TaskAdapter();
            rvTasks = findViewById(R.id.rv_tasks);
            rvTasks.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            rvTasks.setAdapter(taskAdapter);
        }
    }
}