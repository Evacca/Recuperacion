package com.example.recuperacionciclo4;

public enum TaskState {
    PENDING,
    DONE
}
