package com.example.recuperacionciclo4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Registro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState, Object view) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        final EditText nombreR = (EditText) findViewById(R.id.EmailRegister);
        final EditText contraseñaR = (EditText) findViewById(R.id.PasswordRegister);
        final Button btnregistroR = (Button) findViewById(R.id.buttonRegister);
        btnregistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String nombre = nombreR.getText().toString();
                final String contraseña = contraseñaR.getText().toString();
            }
        });
    }
}